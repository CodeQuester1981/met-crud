const express = require("express");
const mongoose = require("mongoose");
const cors = require('cors');
const app = express();
const TodoModel = require("./models/todos");

app.use(express.json())
app.use(cors())

mongoose.connect("mongodb+srv://clarinda:SpiritJas1234@crud.87tpi.mongodb.net/todos?retryWrites=true&w=majority", {
    useNewUrlParser: true,
});

app.post('/insert', async (req, res) => {
    const todoName = req.body.todoName
    const respPerson = req.body.respPerson

    const todo = new TodoModel({ TodoName: todoName, Responsible: respPerson });

    try {
        await todo.save();
    } catch(err) {
        console.log(err)
    }
});

app.get("/read", async (req, res) => {
    TodoModel.find({}, (err, result) => {
        if (err) {
            res.send(err);
        }

        res.send(result);
    });
});

app.put("/update", async (req, res) => {
    const updateItem = req.body.updateItem;
    const id = req.body.id;

    try {
        await TodoModel.findById(id, (err, newItem) => {
            newItem.TodoName = updateItem
            newItem.save();
            res.send("Updated");
        });
    } catch (err) {
        console.log(err);
    }
});

app.delete("/delete/:id", async (req, res) => {
    const id = req.params.id;
    await TodoModel.findByIdAndRemove(id).exec();
    res.send("Item Deleted");
});

app.listen(3001, () => {
    console.log("Server running!");
});