const mongoose = require("mongoose");

const TodoSchema = new mongoose.Schema({
    TodoName: {
        type: String,
        required: true,
    },
    Responsible: {
        type: String,
        required: true,
    },
});

const todos = mongoose.model("todos", TodoSchema)
module.exports = todos