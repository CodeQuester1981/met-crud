import './App.css';
import React, { useState, useEffect } from 'react';
import Axios from 'axios';


function App() {
  const [todoName, setTodoName] = useState("");
  const [respPerson, setRespPerson] = useState("");
  const [updateItem, setUpdateItem] = useState("");
  const [dataList, setDataList] = useState([]);

  useEffect(()=> {
    Axios.get("http://localhost:3001/read").then((response) => {
      setDataList(response.data);
    });
  }, []);

  const addToList = () => {
    Axios.post("http://localhost:3001/insert", {
    todoName: todoName,
    respPerson: respPerson
    });
  };

  const deleteTodo = (id) => {
    Axios.delete(`http://localhost:3001/delete/${id}`)
  };

  const updateTodo = (id) => {
    Axios.put("http://localhost:3001/update", {
      id: id,
      updateItem: updateItem,
    })
  };

  return (
    <div className="App">
      <h1>Todo List</h1>

      <div className="inputs">
        <input type="text" placeholder="Todo Item" onChange={(event) => {setTodoName(event.target.value);}} />
        <input type="text" placeholder="Person Responsible" onChange={(event) => {setRespPerson(event.target.value);}} />
      </div>
      <div className="add">
        <button onClick={addToList}>Add Todo</button>
      </div>
      
      {dataList.map((val, key) => {
        return ( <div key={key}>
          <ul className="output">
            <li>{val.Responsible} : </li> <h3>{val.TodoName}</h3>
          </ul>
          <div className="update">
            <input className="updIn" type="text" placeholder="Update Item" 
                    onChange={(event) => {
                    setUpdateItem(event.target.value);
                  }}
                />
            <button onClick={() => updateTodo(val._id)}>Update</button>
          </div>
          <div className="delete">
            <button onClick={() => deleteTodo(val._id)}>Completed</button>
          </div>
    </div>
    );
  })}
  </div>
  );
}

export default App;
